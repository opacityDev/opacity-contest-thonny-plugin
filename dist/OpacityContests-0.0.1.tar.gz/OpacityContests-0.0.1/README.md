# opacity-contest-thonny-plugin
A Plugin for Opacity contestants who are in love with thonny
